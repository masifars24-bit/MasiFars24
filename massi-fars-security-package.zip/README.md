# Massi Fars - security package

index.html                                   the app (patched)
supabase/security.sql                        RLS + roles + per-user setup steps (run step by step, backup first)
supabase/functions/manage-users/index.ts     admin-only user management (deploy: supabase functions deploy manage-users)
supabase/functions/ai-proxy/index.ts         keeps AI keys on the server (deploy: supabase functions deploy ai-proxy)
firebase/firestore.rules                     deny-all rules for Firestore

Order: 1 test index.html on a test device -> 2 firestore.rules -> 3 disable signups + create admin user
-> 4 security.sql -> 5 deploy manage-users, MF_AUTH.cloud=true, create employee accounts
-> 6 mode:'cloud', then scrub:true -> 7 ai-proxy + MF_AI_PROXY.enabled=true, rotate old AI keys -> 8 final test.

Config switches in index.html (search for them):
  MF_AUTH     { cloud, mode: 'hybrid'|'cloud', domain, fn, scrub }
  MF_AI_PROXY { enabled, url, apikey, providers }
Temporary default admin (fresh devices only): username Zaidfars, password BCvOFR18h478enAU  -> change it in the app.
