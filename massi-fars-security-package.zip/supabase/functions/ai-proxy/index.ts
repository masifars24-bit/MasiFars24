// Supabase Edge Function: ai-proxy
// Keeps AI provider keys on the server. The app sends the signed-in user's token;
// this function checks it, allows only known AI endpoints, adds the secret key, forwards the request.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type Route = { host: string; prefix: string; env: string; kind: "bearer" | "anthropic" | "google" };
const ROUTES: Route[] = [
  { host: "api.openai.com", prefix: "/v1/chat/completions", env: "OPENAI_API_KEY", kind: "bearer" },
  { host: "api.anthropic.com", prefix: "/v1/messages", env: "ANTHROPIC_API_KEY", kind: "anthropic" },
  { host: "generativelanguage.googleapis.com", prefix: "/v1beta/models/", env: "GEMINI_API_KEY", kind: "google" },
  { host: "api.deepseek.com", prefix: "/chat/completions", env: "DEEPSEEK_API_KEY", kind: "bearer" },
  { host: "api.groq.com", prefix: "/openai/v1/chat/completions", env: "GROQ_API_KEY", kind: "bearer" },
  { host: "api.mistral.ai", prefix: "/v1/chat/completions", env: "MISTRAL_API_KEY", kind: "bearer" },
];

const ALLOWED_ORIGIN = Deno.env.get("ALLOWED_ORIGIN") || "*";   // set to your site, e.g. https://example.com
const REQUIRE_ADMIN = Deno.env.get("REQUIRE_ADMIN") === "true"; // true = only role=admin may use AI
const MAX_BODY = 1_500_000;                                      // bytes
const LIMIT = 30, WINDOW_MS = 60_000;                            // 30 requests / minute / user (per instance)
const hits = new Map<string, { n: number; t: number }>();

const cors = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-target-url",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin",
};
const json = (obj: unknown, status: number) =>
  new Response(JSON.stringify(obj), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method" }, 405);

  // 1) who is calling
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!jwt) return json({ error: "no token" }, 401);
  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!);
  const { data, error } = await sb.auth.getUser(jwt);
  if (error || !data?.user) return json({ error: "invalid token" }, 401);
  const user = data.user;
  if (REQUIRE_ADMIN && user.app_metadata?.role !== "admin") return json({ error: "forbidden" }, 403);

  // 2) rate limit
  const now = Date.now();
  const h = hits.get(user.id);
  if (!h || now - h.t > WINDOW_MS) hits.set(user.id, { n: 1, t: now });
  else if (++h.n > LIMIT) return json({ error: "rate limit" }, 429);

  // 3) target must be a known AI endpoint
  let target: URL;
  try { target = new URL(req.headers.get("x-target-url") || ""); } catch { return json({ error: "bad target" }, 400); }
  const route = ROUTES.find((r) => target.protocol === "https:" && target.hostname === r.host && target.pathname.startsWith(r.prefix));
  if (!route) return json({ error: "target not allowed" }, 403);
  const key = Deno.env.get(route.env);
  if (!key) return json({ error: "missing secret " + route.env }, 500);

  // 4) body size cap
  const body = await req.text();
  if (body.length > MAX_BODY) return json({ error: "too large" }, 413);

  // 5) forward with the server-side key
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (route.kind === "bearer") headers["Authorization"] = "Bearer " + key;
  else if (route.kind === "google") headers["x-goog-api-key"] = key;
  else { headers["x-api-key"] = key; headers["anthropic-version"] = "2023-06-01"; }

  const up = await fetch(target.toString(), { method: "POST", headers, body });
  return new Response(up.body, {
    status: up.status,
    headers: { ...cors, "Content-Type": up.headers.get("content-type") || "application/json" },
  });
});
