// Supabase Edge Function: manage-users
// Only a signed-in ADMIN (app_metadata.role = "admin") can call it.
// Creates / updates / deletes per-user accounts. username -> email "<username>@<EMAIL_DOMAIN>".
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const DOMAIN = Deno.env.get("EMAIL_DOMAIN") || "mf.local";          // must match MF_AUTH.domain in the app
const ALLOWED_ORIGIN = Deno.env.get("ALLOWED_ORIGIN") || "*";
const ROLES = ["admin", "employee"];

const cors = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Headers": "authorization, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin",
};
const json = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });

// MUST stay identical to mfEmail() in the app
function emailFor(u: string): string {
  u = String(u || "").trim().toLowerCase();
  if (/^[a-z0-9._-]{1,40}$/.test(u)) return `${u}@${DOMAIN}`;
  const b = new TextEncoder().encode(u);
  return "u" + Array.from(b).map((x) => x.toString(16).padStart(2, "0")).join("") + "@" + DOMAIN;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return json({ error: "method" }, 405);

  const url = Deno.env.get("SUPABASE_URL")!;
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!jwt) return json({ error: "no token" }, 401);

  const anon = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!);
  const { data: who, error: werr } = await anon.auth.getUser(jwt);
  if (werr || !who?.user) return json({ error: "invalid token" }, 401);
  const caller = who.user;
  if (caller.app_metadata?.role !== "admin") return json({ error: "forbidden" }, 403);

  const svc = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

  async function findByEmail(email: string) {
    for (let page = 1; page <= 20; page++) {
      const { data, error } = await svc.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) throw error;
      const hit = data.users.find((u) => (u.email || "").toLowerCase() === email.toLowerCase());
      if (hit) return hit;
      if (data.users.length < 1000) break;
    }
    return null;
  }

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "bad json" }, 400); }
  const action = String(body.action || "");

  try {
    if (action === "list") {
      const out: { username: string; role: string }[] = [];
      for (let page = 1; page <= 20; page++) {
        const { data, error } = await svc.auth.admin.listUsers({ page, perPage: 1000 });
        if (error) throw error;
        for (const u of data.users) out.push({ username: u.user_metadata?.username || u.email || "", role: u.app_metadata?.role || "" });
        if (data.users.length < 1000) break;
      }
      return json({ users: out });
    }

    const username = String(body.username || "").trim();
    if (!username || username.length > 30) return json({ error: "bad username" }, 400);

    if (action === "upsert") {
      const role = String(body.role || "");
      if (!ROLES.includes(role)) return json({ error: "bad role" }, 400);
      const password = body.password ? String(body.password) : "";
      if (password && password.length < 8) return json({ error: "password too short (min 8)" }, 400);

      const target = emailFor(username);
      const old = body.oldUsername ? emailFor(String(body.oldUsername)) : target;
      let user = await findByEmail(old);
      if (!user && old !== target) user = await findByEmail(target);

      if (!user) {
        if (!password) return json({ error: "password required for a new account" }, 400);
        const { error } = await svc.auth.admin.createUser({
          email: target, password, email_confirm: true,
          app_metadata: { role }, user_metadata: { username },
        });
        if (error) return json({ error: error.message }, 400);
        return json({ ok: true, created: true });
      }
      if (body.createOnly) return json({ ok: true, existed: true });
      if (user.id === caller.id && role !== "admin") return json({ error: "cannot demote yourself" }, 400);
      const patch: Record<string, unknown> = {
        email: target, email_confirm: true,
        app_metadata: { ...(user.app_metadata || {}), role },
        user_metadata: { ...(user.user_metadata || {}), username },
      };
      if (password) patch.password = password;
      const { error } = await svc.auth.admin.updateUserById(user.id, patch);
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true, updated: true });
    }

    if (action === "delete") {
      const user = await findByEmail(emailFor(username));
      if (!user) return json({ ok: true, missing: true });
      if (user.id === caller.id) return json({ error: "cannot delete yourself" }, 400);
      const { error } = await svc.auth.admin.deleteUser(user.id);
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true, deleted: true });
    }

    return json({ error: "unknown action" }, 400);
  } catch (e) {
    return json({ error: String((e as Error)?.message || e) }, 500);
  }
});
