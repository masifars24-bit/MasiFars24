-- ===== Massi Fars: Supabase hardening =====
-- Run in Supabase > SQL Editor, step by step. Replace ADMIN_EMAIL first.

-- STEP 0: backup (do this first)
create table if not exists public.sync_records_backup as table public.sync_records;

-- STEP 1: admin role check (reads role from the signed JWT, not from the client)
create or replace function public.is_admin() returns boolean
language sql stable as $$
  select coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'admin'
$$;

-- STEP 2: mark YOUR admin account. Create it first in Authentication > Users,
-- then run this. The admin must sign out and in again in the cloud gate.
update auth.users
   set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
 where email = 'ADMIN_EMAIL';

-- STEP 3: remove all old policies, then add strict ones
alter table public.sync_records   enable row level security;
alter table public.public_receipts enable row level security;

do $$
declare r record;
begin
  for r in select policyname, tablename from pg_policies
           where schemaname = 'public' and tablename in ('sync_records', 'public_receipts')
  loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

revoke all on public.sync_records from anon;

-- sync_records: everyone signed in can read/write normal data;
-- only admin can touch the kill-switch / wipe rows, and only admin can DELETE.
create policy sr_select on public.sync_records for select to authenticated using (true);
create policy sr_insert on public.sync_records for insert to authenticated
  with check (key not in ('__sysctl__', '__wipe__') or public.is_admin());
create policy sr_update on public.sync_records for update to authenticated
  using      (key not in ('__sysctl__', '__wipe__') or public.is_admin())
  with check (key not in ('__sysctl__', '__wipe__') or public.is_admin());
create policy sr_delete on public.sync_records for delete to authenticated
  using (public.is_admin());

-- public_receipts: signed-in users manage them (no anon access to the table)
create policy pr_select on public.public_receipts for select to authenticated using (true);
create policy pr_insert on public.public_receipts for insert to authenticated with check (true);
create policy pr_update on public.public_receipts for update to authenticated using (true) with check (true);
create policy pr_delete on public.public_receipts for delete to authenticated using (true);

-- STEP 4 (only after checking): public receipt links use the RPC get_public_receipt.
-- It must be SECURITY DEFINER, otherwise anon cannot read receipts once the table is locked.
--   select proname, prosecdef from pg_proc where proname = 'get_public_receipt';
-- If prosecdef = false, run (adjust the argument type if different):
--   alter function public.get_public_receipt(text) security definer set search_path = public;
--   grant execute on function public.get_public_receipt(text) to anon;
-- Then test a receipt link in a private window.

-- STEP 5 (Dashboard): Authentication > Rate Limits / Attack Protection:
-- enable CAPTCHA and keep sign-in rate limits on.
-- Database > Backups: enable daily backups (Pro: Point-in-Time Recovery).

-- ===== PER-USER ACCOUNTS (login with username) =====
-- username "ahmad" becomes the Supabase user "ahmad@mf.local" (non-ASCII names are hex-encoded automatically).
-- 1) Dashboard > Authentication > Sign In / Providers > Email:
--      turn OFF "Allow new users to sign up"  (otherwise anyone can create an account and read your data)
-- 2) Create YOUR admin user in Authentication > Users > Add user
--      email: <admin username in lowercase>@mf.local   e.g. zaidfars@mf.local   (tick "Auto confirm")
--    then run STEP 2 above with that email (sets role = admin).
-- 3) Deploy the function:   supabase functions deploy manage-users
--      optional secrets:    supabase secrets set EMAIL_DOMAIN=mf.local ALLOWED_ORIGIN=https://your-site
--    (SUPABASE_URL / ANON_KEY / SERVICE_ROLE_KEY are provided automatically.)
-- 4) In index.html set  window.MF_AUTH = { cloud: true, mode: 'hybrid', domain: 'mf.local', fn: '' }
-- 5) Log in as admin, open the cloud panel > "create cloud accounts for employees",
--    give each employee the temporary password from the downloaded file.
-- 6) When everybody can log in with the cloud account, set mode: 'cloud' (strict).
-- 7) Finally delete the old shared sync user in Authentication > Users.
-- If Supabase rejects the "mf.local" email domain, use another domain you own in BOTH
-- MF_AUTH.domain and the EMAIL_DOMAIN secret.

-- ===== AFTER everyone logs in with the cloud account (mode: 'cloud') =====
-- Set  MF_AUTH.scrub = true  in index.html. The next time the ADMIN logs in, password hashes are
-- removed from mf_employees and mf_admin_account and the cleaned data syncs to every device.
-- This cannot be undone. Old copies of the hashes still exist in:
--   * public.sync_records_backup (created in STEP 0)  ->  drop table public.sync_records_backup;  (after you verified everything)
--   * old backup files you exported from the app (delete them)
--   * your Firebase project (if the old mirror ever ran): delete the Firestore data in the Firebase Console
